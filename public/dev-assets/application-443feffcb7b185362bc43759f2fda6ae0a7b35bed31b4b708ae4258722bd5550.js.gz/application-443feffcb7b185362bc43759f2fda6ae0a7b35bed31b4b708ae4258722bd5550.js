<script type="module">
  import Rails from "@rails/ujs";
  Rails.start();
</script>;
